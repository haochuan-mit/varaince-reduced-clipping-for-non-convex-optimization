from .sgd import SGD
from .gd import GD
from .svrg import SVRG
from .sarah import SARAH
